<!DOCTYPE html>
<html>
<head>
    <style type="text/css">
    #google_translate_element {
        display: none;
    }
    /*
    .goog-te-banner-frame {
        display: none !important;
    }
    body {
        position: static !important;
        top: 0 !important;
    }
    */

#google_translate_element {
    display: none;
}
.goog-te-banner-frame {
    display: none !important;
}
body {
    position: static !important;
    top: 0 !important;
}
    </style>
</head>
<body>
    <div id="google_translate_element" class="boxTradutor"></div>

    <a href="javascript:trocarIdioma('pt')"><img alt="português" src="images/icon-pt.png"></a>
    <a href="javascript:trocarIdioma('es')"><img alt="espanhol" src="images/icon-es.png"></a>
    <a href="javascript:trocarIdioma('en')"><img alt="ingles" src="images/icon-en.png"></a>

    <p>Olá pessoal  ! Esse é o teste do Google Translate inserido e customizado nas páginas WEB.</p>
    <p>Caso tenha alguma dúvida pode entrar em contato comigo: www.compuvision.com.br</p>
    <p>Abraços à todos e boa sorte !</p>


    <!-- O Javascript deve vir depois -->

    <script type="text/javascript">
    var comboGoogleTradutor = null; //Varialvel global

    function googleTranslateElementInit() {
        new google.translate.TranslateElement({
            pageLanguage: 'pt',
            includedLanguages: 'en,es,pt',
            layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL
        }, 'google_translate_element');

        comboGoogleTradutor = document.getElementById("google_translate_element").querySelector(".goog-te-combo");
    }

    function changeEvent(el) {
        if (el.fireEvent) {
            el.fireEvent('onchange');
        } else {
            var evObj = document.createEvent("HTMLEvents");

            evObj.initEvent("change", false, true);
            el.dispatchEvent(evObj);
        }
    }

    function trocarIdioma(sigla) {
        if (comboGoogleTradutor) {
            comboGoogleTradutor.value = sigla;
            changeEvent(comboGoogleTradutor);//Dispara a troca
        }
    }
    </script>
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</body>
</html>